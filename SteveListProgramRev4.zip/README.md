# My first Vue App
## It's a basic text entry planner app









### Language stuff that could be important

- [VS Code](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur) + [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin).

- also useful is the [vue guide](https://vuejs.org/guide/typescript/overview.html#volar-takeover-mode) for how to enable takeover mode
