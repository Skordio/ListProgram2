<template>
    <button class="button">Delete</button>
</template>

<script lang="ts">
    import { defineComponent } from 'vue'
    export default defineComponent({
    })

</script>

<style scoped>

.button {
    position: relative;
    left: 0.5em;
}

</style>