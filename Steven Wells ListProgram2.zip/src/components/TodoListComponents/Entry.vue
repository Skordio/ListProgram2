<template>
    <!-- Buttons -->
        <ToDoEditButton @click="editThisEntry()" />
        <ToDoDeleteButton @click="deleteThisEntry()" />

    <!-- Input for edits -->
        <input 
            ref="editingInput"
            v-model="editedMessage" 
            v-if="editingPreview == true"
            @keydown.enter="editThisEntry()"
            style=" position: absolute;
                    word-wrap: break-word;
                    z-index: 10; 
                    top: .4em;
                    left: 10.8em;
                    font-size: 1em;
                    width:55.5em;
                    text-align: left;"/>

    <!-- Note details -->
        <p  v-if="editingPreview == false" 
            style=" position: absolute; 
                    top: -0.6em;
                    left: 11em; 
                    font-size: 1em; 
                    width:36em; 
                    text-align: left;"
            :style="{'z-index': zvalue}" >

            {{ details }}
        </p>

    <!-- Date -->
        <p  style=" position: absolute; 
                    top: -0.6em; 
                    left: 11em;
                    font-size: 1em; 
                    width:66.5em; 
                    text-align: right;" >

            {{created.toLocaleTimeString()}} {{created.toLocaleDateString()}} 
        </p>
        <div :style="{height: calculatePadding() + 0.5 + 'em'}"></div>

</template>

<script lang="ts">
import { defineComponent } from 'vue'
import ToDoDeleteButton from './DeleteButton.vue';
import ToDoEditButton from './EditButton.vue';
import ToDoList from '../ToDoList.vue';
export default defineComponent({
    methods: {
        deleteThisEntry() {
            this.$emit('delete')
        },
        editThisEntry() {
            if(this.editingPreview) {
                this.zvalue = 10;
                this.$emit('edit', this.editedMessage)
                this.editingPreview = false;
            } else {
                this.zvalue = -20;
                this.editingPreview = true;
            }
        },
        // This padding method isn't great but works a little
        calculatePadding() {
            return (this.characters!)/(63);
        }
    },
    components: {
        ToDoDeleteButton,
        ToDoEditButton
    },
    props: {
        details: String,
        characters: Number,
        key: Number
    },
    data() {
        return {
            editingPreview: false,
            editedMessage: this.details,
            created: new Date(),
            zvalue: 10 //the z value for the note details
        }
    }
})


</script>
