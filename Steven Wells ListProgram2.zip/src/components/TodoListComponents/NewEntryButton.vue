<template>
    <button>Add Entry</button>
</template>

<script lang="ts">
import {defineComponent } from 'vue'
export default defineComponent({
})

</script>

