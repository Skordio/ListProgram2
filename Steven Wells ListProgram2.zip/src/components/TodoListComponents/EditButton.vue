<template>
    <button class="button">Edit</button>
</template>

<script lang="ts">
    import { defineComponent } from 'vue'
    export default defineComponent({
    })
</script>

<style scoped>

.button {
    position: relative;
}

</style>